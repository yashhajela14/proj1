package com.yash.springboot.web.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.yash.springboot.web.service.TodoService;

@Controller
@SessionAttributes("name")
public class ToDOController {
	
	@Autowired
	TodoService todoService;

	@RequestMapping(value = "/todolist", method = RequestMethod.GET)
	public String getTodoList(ModelMap model) {
		String name = (String)model.get("name");
		System.out.println(name);
		model.put("todos", todoService.retrieveTodos(name));
		return "list-todos";

	}
	
	@RequestMapping(value = "/addtodo", method = RequestMethod.GET)
	public String ShowAddTodoList(ModelMap model) {

		return "add-todos";

	}
	
	@RequestMapping(value = "/addtodo", method = RequestMethod.POST)
	public String addTodoList(ModelMap model, @RequestParam String desc) {
		
		todoService.addTodo((String)model.getAttribute("name"), desc, new Date(), false);
		return "redirect:/todolist";

	}
	
}
